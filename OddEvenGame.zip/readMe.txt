For part 1:
Instance variables: I created some scanners to allow for user input and some int instance variables to keep track of scores, tresholds, and the winner. I also had two ComputerPlayer Objects. 
Game constructor: I used a scanner to allow the user to pick their player. Then I instantiated the computer player object depending on the user choice.
Play method: I used a scanner to let the user play their turn, then I played the computer with the playComp() method from the ComputerPlayer class, then I found the sum of the two players and used that to find the winner and the average winnings.
At the end, I used the scanner to ask the user if they want to play again and I used this.play() depending on the user input. 
After the user decides they are done playing, the method prints the winner and the average winnings for each player. 

For part 2:
ComputerPlayer class: I added a playComp method that simulates the computer turn. It returns 1 or 2 depending on a random double in relation to the threshold parameter.
Game constructor: I set the threshold parameter variables to my instane variables and instantiated my computer player objects.
Play method: I created computer player objects and a for loop that plays the game a certain number of times. I kept track of the winner and average scores of each player. 
I did this with a counter and sum variable. The method prints the winner and the average winnings for each player.  

Simulation: I followed Prof Cannon's algorithm of keeping track of the min, currentMin, and maxMin scores in order to find the optimal threshold values.
I created a nested for loop that runs through different treshold values for each player. I incremented by 0.02 and played 100,000 games.
I kept track of the minimum min score, the current min score, and the maximum min score.
If the maxMin score was greater than 0, player 1 had the advantage. If maxMin = 0, the game was fair. If maxMin < 0, player 2 had the advantage. 
I took some time to try and understand the math behind the algorithm before starting to code it. I watched Melody's video, and I understand why p1 should have the advantage and why the optimal t value should be 7/12.
I am not sure if this is reflected in my code though. I don't know if the issue is in my play(games) method or my simulation, but my simTest returns player 2 with an advantage. 
When I run simulation, I get the same outcome after each round, which I don't think should be happening but could not figure out how to fix.


I've had this error for the 24 hours, so I stopped by office hours today (3/12), but I don't think they were happening as scheduled due to spring break. I don't know if feedback is possible, but I would love to know how to fix the code in the future!