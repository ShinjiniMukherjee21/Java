/**
 * This class represents a computer
 * player in the Odd-Even game
 * 
 * name: Shinjini Mukherjee
 * UNI: sm5160
 */

public class ComputerPlayer{
    
    private double t;
    private int tokenBalance;
    
    public ComputerPlayer(double threshold){
        threshold = t;
        tokenBalance=0;
    }
    
    //adding a playComp() method that is the computer player turn
    public int playComp() {

        //getting a random value to compare the treshold to
        double random = Math.random();
    
        if(random < t) {
            return 1;
        }  

        else {
            return 2;
        }

    }
  
    
}