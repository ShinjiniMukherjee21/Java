/**
 * This class should run simulations to determine
 * whether or not the Odd-Even game is fair and if
 * not who has the advantage and what is a strategy
 * that will realize that adavantage.
 * 
 * name: Shinjini Mukherjee
 * UNI: sm5160
 * 
 */


public class Simulation{
    
    public static void main(String[] args){
       
       int maxS = 0;
       int minScore = 0;
       int maxMinScore = 0;
       int tempMinScore = 0;


        //looping through and incrementing treshold values for each player
        //maxMin is player 1 treshold with largest minimum value for each player 2 treshold
        for (int s = 0; s <= 1; s += .02) {

            for (int t = 0; t <= 1; t += .02) {
                
                //creating a simulation game
                Game sim = new Game(s, t);

                tempMinScore = sim.getP1Score();

                sim.play(100000);

                minScore = (sim.getP1Score() / 100000);
                
                if (minScore < tempMinScore) {
                    minScore = tempMinScore;
                }

            }

            //seeing if the min score is greater than the current maxMin score
            if (minScore > maxMinScore) {
                maxMinScore = minScore;
                maxS = s; //optimal treshold value
            }
        }


        
        //if maxMin is positive --> p1 has advantage
        //if maxMin is negative --> p2 has advantage
        //if maxMin is 0 --> fair game
        
        if(maxMinScore > 0) {
            System.out.println("Player 1 has advantage.");
        }

        else if(maxMinScore == 0) {
            System.out.print("Fair game");
        }

        else {
            System.out.println("Player 2 has advantage.");
        }

        //printing the optinal t value
        System.out.print(maxS);

    }

    
}