/**
 * A tester for the Odd-Even game.
 * Your code must work with this program. Do not modify this class.
 * 
 *  
 */

public class OddEven{
    public static void main(String[] args){
        Game g = new Game();
        g.play();
    
    }
}