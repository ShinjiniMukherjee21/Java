/**
 * This class represents the Odd-Even game
 * 
 * name: Shinjini Mukherjee
 * UNI: sm5160
 * 
 */
import java.util.Scanner;

public class Game{
    
    // your instance variables here:
    
    private ComputerPlayer p1;
    private ComputerPlayer p2;

    private boolean isComputerP1;

    private int treshold1;
    private int treshold2;

    private int scoreP1;
    private int scoreP2;

    private int winner;

    private Scanner humanChoice; //human
    private Scanner input;
    private int playerChoice; //human decides their turn



/* this version of the game constructor is for Part 1
 * it takes no parameters */
    public Game(){
        
        //asking user which player they want to be
        System.out.print("Please enter 1 or 2 for which player you want to be:");
        Scanner humanChoice = new Scanner(System.in);
        playerChoice = humanChoice.nextInt();   

        p2 = new ComputerPlayer(0.5);
        p1 = new ComputerPlayer(0.5);
        
        //instantiating computer player based on user decision
        if (playerChoice == 1) {
            p2 = new ComputerPlayer(0.5);
            isComputerP1 = false;
        }

        else {
            p1 = new ComputerPlayer(0.5);
            isComputerP1 = true;

        }

        //keeping track of variables 
        scoreP1 = 0;
        scoreP2 = 0;
        winner = 0;
    }
    
/* this version of the game constructor is for Part 2
 * It requires two doubles as parameters. You will use 
 * these to set the initial thresholds for you computer players */

 //use this method in the nested loop for simulation
    public Game (double t1, double t2){
    
        //setting parameters instance variables
        t1 = treshold1;
        t2 = treshold2;

        ComputerPlayer p1 = new ComputerPlayer(t1);
        ComputerPlayer p2 = new ComputerPlayer(t2);

        //keeping track of variables
        scoreP1 = 0;
        scoreP2 = 0;
        winner = 0;
        
    }
    
/* this version of the play method is for Part 1
 * It takes no parameters and should play the interactive
 * version of the game */
    public void play(){
        
        //letting the user play their turn with a scanner
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your turn: ");
        int humanTurn = input.nextInt();
        
        //local variables to keep track of sum and number of games
        int sum = 0;
        int counter = 0;
        int computerTurn = 0;

        //letting the computer play depending on which player they are
        if(isComputerP1 == true) {
            computerTurn = p1.playComp();
        }

        else {
            computerTurn = p2.playComp();
        }

        //finding the sum of the two players
        sum = humanTurn + computerTurn;

        //checking if sum is odd or even
        if(sum % 2 == 1) {
            winner = 1;
            scoreP1 += sum;
            scoreP2 -= sum;
        }

        else if (sum % 2 == 0) {
            winner = 2;
            scoreP2 += sum;
            scoreP1 -= sum;
        }

        //getting average scores
        counter++;
        int avg1 = scoreP1 / counter;
        int avg2 = scoreP2 / counter;
        

        //play another round
        System.out.println("Enter 1 to play again or enter 2 to end: ");
        int again = input.nextInt();

        if(again == 1) {
            this.play();
        }

        //printing winner and average scores
        else {
            System.out.println("The winner is player " + winner);
            System.out.println("Player 1 scored an avg of " + avg1 + "points");
            System.out.println("Player 2 scored an avg of " + avg2 + "points");
        }

    }
    
    
/** this version of the play method is for Part 2
 * It takes a single int as a parameter which is the
 * number of computer vs. computer games that should be played */
    public void play(int games){
        
        ComputerPlayer P1 = new ComputerPlayer(treshold1);
        ComputerPlayer P2 = new ComputerPlayer(treshold2);

        //playing each computer player for a certain number of games
        for(int i = 0; i < games; i++) {

            //letting each computer play
            int turnP1 = P1.playComp();
            int turnP2 = P2.playComp();
            
            //finding sum of turns
            int sum = turnP1 + turnP2;
            
            //checking if sum is odd or even and adding to score totals
            if(sum % 2 == 1) {
                winner = 1;
                scoreP1 += sum;
                scoreP2 -= sum;
            }

            else {
                winner = 2;
                scoreP2 += sum;
                scoreP1 -= sum;
            }

        }

        //getting the average scores
        int avg1 = scoreP1 / games;
        int avg2 = scoreP2 / games;

        //printing the winner and average scores
        System.out.println("The winner is player " + winner);
        System.out.println("Player 1 scored an avg of" + avg1 + "points");
        System.out.println("Player 2 scored an avg of" + avg2 + "points");


    }

/* this method should return the current score (number of tokens)
 * that player 1 has */
    public int getP1Score(){
    
        return scoreP1;
        
    }
    
/* this method should return the current score (number of tokens)
 * that player 2 has */
    public int getP2Score(){
      
        return scoreP2;

    }  
    
 
}