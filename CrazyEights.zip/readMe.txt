Shinjini Mukherjee, sm5160

I worked with Dave Banerjee and Adam Frommer.

Card: I followed Professor Cannon's outline for the Card class that he went over in lecture.

Deck: I followed Professor Cannon's suggestions for the Deck class. I created a nested for loop to create a deck with 52 cards varying between the 4 suits and 13 ranks. 
deal() just increments the top card and then returns ("deals") it. 
canDeal() just makes sure there are cards left in the deck. You have to check the top card for canDeal() because a deck is an array with a fixed length.
shuffle() creates a temp card and a random index and swaps the temp card with the card from a random index. The for loop suffles every card in the deck.
toString() just prints the deck. I created a separate test class to make sure all the Deck methods worked.

Game: 
For the constructor, I initialized the instance variables. I then shuffled the deck of cards and created a hand for the human and computer. I dealt the first faceup card and kept track of its suit as currentSuit.
I wrote the play() and end() methods in the Game class last. I started with playComp(), a sub method I created for computerTurn().
playComp() assumes that the computer can play and then compares the faceup card to every card in the computer's hand.
There is a special case to check for an 8, which just sets the faceup to the 8 card.
The computer only plays an 8 if it can play no other card. If there is no 8, the computer draws.
computerTurn() is essentially the same as playComp(), except it checks the size of compHand and the value of faceup before calling playComp().
computerTurn() also deals with printing out the happenings of the computer's move. 
openingMessage() is just a helper method that deals with the text at the beginning of the game. It is called at the beginning of play().
I wanted to create another helper method that would convert a c to Clubs, an s to Spades, etc. I kept getting an error, so I just ended up using conditionals to do this within the other methods.
play() prints the opening message and then goes back and forth between the human and the computer's turns. 
The while true loop ensures that there is no reason to end the game. Before each turn, the size of the hand, canDeal(), and the value of faceup is checked to make sure that the game can still continue.
I wanted to write a boolean playable() method to shorten play(), but I ended up realizing this after writing out play(). 
playable() would have just checked the conditions of the game to make sure the game was not over.
end() is a sub method that is called in play() when a condition is met that ends the game.
end() deals with figuring out the winner, the number of cards left in each hand, if there is a tie, if the deck ran out of cards, etc.

Player:
For the constructor, I initialized the instance variables. 
playsTurn() deals with the logic of the human. It asks the user if they want to draw or play, then it checks their input, and then it modifies the hand accordingly. 
getHand() just returns the player's hand.
handToString() prints the player's hand. This is used in the play() method to display the player's hand before the playsTurn() method is called. 