/** Card.java
*   Author: Shinjini Mukherjee
*   UNI: sm5160
*   
*   Models a typical playing card
*
*/

class Card{
    
    private char suit;
    private int rank;

    // Initializes a card instance
    public Card(char suit, int rank){
        this.suit = suit; //c = club, h = heart, s = spade, d = diamond
        this.rank = rank; //ace is one...king is thirteen
    }

    // Accessor for suit
    public char getSuit(){
        return suit;
    }
    
    // Accessor for rank
    public int getRank(){
        return rank;
    }

    // Returns a human readable form of the card (eg. King of Diamonds)
    public String toString(){
        
        String tempRank = "";
        String actualSuit = "";

        if(rank >= 2 && rank <= 10) {
            tempRank = tempRank + rank;
        }

        else if (rank == 1) {
            tempRank = "Ace";
        }

        else if (rank == 11) {
            tempRank = "Jack";
        }

        else if (rank == 12) {
            tempRank = "Queen";
        }

        else if (rank == 13) {
            tempRank = "King";
        }

        if (suit == 'c') {
            actualSuit = "Clubs";
        }

        else if (suit == 'd') {
            actualSuit = "Diamonds";
        }

        else if (suit == 'h') {
            actualSuit = "Hearts";
        }

        else if (suit == 's') {
            actualSuit = "Spades";
        }

        String output = tempRank + " of " + actualSuit;

        return output;

    }

}