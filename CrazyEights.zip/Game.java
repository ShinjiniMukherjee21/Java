/** Game.java
*   Author: Shinjini Mukherjee
*   UNI: sm5160
*   
*   Game class for playing crazy eights in commandline
*   To be used with Player, Card, Deck classes
*
*/

import java.util.Scanner;
import java.util.ArrayList;

class Game{

    private char currentSuit; // need in case an 8 is played
    private Card faceup; 
    private Scanner input;
    private Player p1;
    private ArrayList<Card> compHand;
    private Deck cards;
    
    // sets up the Game object for play
    public Game(){
        
        input = new Scanner(System.in);
        p1 = new Player();
        cards = new Deck();
        compHand = new ArrayList<Card>();

        cards.shuffle();
         
        for (int i = 0; i < 7; i++) {
            compHand.add(cards.deal());
            p1.addCard(cards.deal());
        }

        faceup = cards.deal(); 
        currentSuit = faceup.getSuit();
    }

    // Plays a game of crazy eights. 
    // Returns true to continue playing and false to stop playing
    public boolean play(){

        //check two conditions: size of each hand, faceup card is not null
        //interacts between game and player class
        //player one takes their turn, player two takes their turn 
        //can play as long as there are cards left in each deck 
        //return end method when one of the end conditions are met

        openingMessage(); 

        while (true) {

            System.out.println("Your cards are: " + "\n" + p1.handToString()); 

            faceup = p1.playsTurn(cards);

            if( cards.canDeal() == false || p1.getHand().size() == 0 || faceup == null) {
                System.out.println("Game Over.");
                return end();
            }

            else if (faceup.getRank() == 8) {
                System.out.println("Choose a suit to set! (c,h,d,s)");
            
                Scanner input = new Scanner(System.in);
                String suitChoice = input.nextLine();

                if (suitChoice.equals("c")) {
                    suitChoice = "Clubs";
                }

                else if (suitChoice.equals("d")) {
                    suitChoice = "Diamonds";
                }

                else if (suitChoice.equals("h")) {
                    suitChoice = "Hearts";
                }

                else if (suitChoice.equals("s")) {
                    suitChoice = "Spades";
                }

                System.out.println("The current suit is " + suitChoice);
                currentSuit = suitChoice.charAt(0);
            } 

            
            if(cards.canDeal() == true) {
                faceup = computerTurn();

                if (cards.canDeal() == false || faceup == null || compHand.size() == 0) {
                    System.out.println("Game over.");
                    return end();
                }  
            }    

        }

    }    

   public boolean end() {

        //figure out why game ended
        //say who won
        //ask if user wants to play again --> return true/false
        //check the players' hands to see if cards are left and check who has fewer cards

        System.out.println("You have " + p1.getHand().size() + " cards left");
        System.out.println("The computer has " + compHand.size() + " cards left");

        if (p1.getHand().size() == 0) {
            System.out.println("You win.");
        }

        else if (compHand.size() == 0) {
            System.out.println("Computer wins.");
        }

        else if (cards.canDeal() == false) {
            System.out.println("The deck has run out of cards.");

            if (p1.getHand().size() < compHand.size()) {
                System.out.println("You win.");
            }

            else if (p1.getHand().size() > compHand.size()) {
                System.out.println("Computer wins.");
            }

            else if (p1.getHand().size() == compHand.size()) {
                System.out.println("The result is a tie.");
            }
        }

        System.out.println("Do you want to play again? Enter yes or no.");
        String response = input.nextLine();

        if (response.equals("yes")) {
            return true;
        }

        else {
            System.out.println("Thanks for playing!");
            return false;
        }
        
    }

    /* Naive computer player AI that does one of two actions:
        1) Plays the first card in their hand that is a valid play
        2) If no valid cards, draws until they can play

        You may choose to use a different approach if you wish but
        this one is fine and will earn maximum marks
     */
    private Card computerTurn(){

        //check deck size to see if you can still return a card. if not, return null 

        if(compHand.size() != 0 && cards.canDeal() == true) {

            Card returnCard = playComp();
            System.out.println("** The computer played a " + returnCard.toString() + " **" + "\n");
            System.out.println("** The up card is " + faceup.toString() + " **");

            String str = Character.toString(faceup.getSuit());

            if (str.equals("c")) {
                str = "Clubs";
            }

            else if (str.equals("d")) {
                str = "Diamonds";
            }

            else if (str.equals("h")) {
                str = "Hearts";
            }

            else if (str.equals("s")) {
                str = "Spades";
            }

            System.out.println("The current suit is " + str + " \n");
            return returnCard;

        }

        else {
            return null;
        }

    }

    private Card playComp() {
        //simulates computer turn assuming that a card can be returned
        //creating a method of the same return type to sub into computerTurn()

        char tempSuit = currentSuit; //should be same as faceup.getSuit()
        int tempRank = faceup.getRank();

        for (int i = 0; i < compHand.size(); i++) {

            if (compHand.get(i).getSuit() == tempSuit || compHand.get(i).getRank() == tempRank) {
                Card returnCard = compHand.get(i);
                faceup = compHand.get(i);
                compHand.remove(i);
                return returnCard;
            }

            else if (compHand.get(i).getRank() == 8) {
                currentSuit = compHand.get(i).getSuit();
                Card returnCard = compHand.get(i);
                faceup = compHand.get(i);
                compHand.remove(i);
                return returnCard;
            }

        }
   
        while (cards.getLength() != 0) {
            Card draw = cards.deal();
            if (draw.getSuit() == tempSuit || draw.getRank() == tempRank) {
                faceup = draw;
                return draw;
            }

            else if (draw.getRank() == 8) {
                currentSuit = draw.getSuit();
                faceup = draw;
                return draw;
            }

            else {
                compHand.add(draw);
            }
        } 

        return null; //this will be the only option left if no card is played --> means that no cards left in deck.

    }
        
    public void openingMessage() {
        //printing the message at the beginning of the game
        //call this method at the beginning of play()

        System.out.println("\n" + "Welcome to Crazy Eights! You'll start with 7 cards.");
        System.out.println("Your job is to match a card in your hand with the up card.");
        System.out.println("You can match it by suit or rank.");
        System.out.println("If you play an 8, you can switch the active suit.");
        System.out.println("If you run out of cards, you win!");
        System.out.println("If you make it through the whole deck then whoever has the fewest cards left wins!");
        System.out.println("Good luck!");
        System.out.println("\n" + "** The up card is " + faceup.toString() + " **");
        String str = Character.toString(currentSuit);

        if (str.equals("c")) {
            str = "Clubs";
        }

        else if (str.equals("d")) {
            str = "Diamonds";
        }

        else if (str.equals("h")) {
            str = "Hearts";
        }

        else if (str.equals("s")) {
            str = "Spades";
        }

        System.out.println("The current suit is " + str + "\n");
        
    }

} //end