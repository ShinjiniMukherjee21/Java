# COMS W1004
## Spring 2022
## Programming Project 4
## Due April 4 at 11:59PM 
______________________________________

**Crazy Eights! (70 points):**  
*Designed by Ben Snyder with special thanks to our TA leadership team for their contributions to this assignment: Chianna Cohen, Melody Hsu, Ricky Shin, and Annie Sui!*

In this project you will implement a ***variation*** of the card game Crazy Eights. This simplified version will make your work a little easier.You ***must*** implement the version of the game described here, anything else will not be accepted.   

The game is played between two players using a standard 52 card deck. Here's how it works:

* Seven cards are dealt to each player  
* The remaining cards are placed in a pile face down. This pile is called the "stock pile"
* The top card on the stock pile is removed and turned face up. It is now the first card in a new pile called the "discard pile". (Notice the stock pile cards are face down and the discard pile is face up.)
* Each turn a player discards a card from their hand into the discard pile by matching either the suit or the rank of the top card of the discard pile. If the player has no cards in their hand that match the suit or the rank, they must draw from the stock pile until they get a playable card or they may play an eight. The player's discarded card is now the top card of the discard pile.
* Eights are wild. That means an eight may be played at any time and the player discarding the eight then chooses the suit they wish the next player to have to match.
* If a player discards the final card in their hand, they win.
* If the stock pile is exhausted, the game ends and the player with the fewest cards left in their hand is declared the winner. 

**NOTES:** This is not exactly the standard game so make sure you understand how to play. To that end you can play this version of the game here by opening up a terminal and typing "play" (to stop playing early just press control-c). Your solution does not have to be exactly like what you see here but it should be pretty similar. 

**Scaffolding** To help you with your design I have provided some scaffolding:

1. `CrazyEights.java`: This is the test class you should not alter this class and your program ***must*** work with this tester.
2. `Game.java`: An outline of the Game class that you need to write is here. You may add methods if you wish but try not to add any instance variables. It's okay if you end up adding one or two, but you shouldn't need to.
3. `Player.java`: An outline of the Player class that you need to write is here. You may add methods if you wish but try not to add any instance variables. It's okay if you end up adding one or two, but don't get carried away.
4. `Deck.java`: An outline of the Deck class that you need to write is here. We will discuss this in class to help get you started.
5. `Card.java`: An outline of the Card class that you need to write is here. This one we will write together in class.

**FAQ**
* *Can we assume that the user input is in the correct format?*
You can assume the user is well behaved. That is, you can assume that user will not input numbers or strings that are out of range and will generally follow formatting instructions when providing input.
* *Can we assume the user does not try to cheat by playing cards that don't match the up card?*
You may make this assumption and still earn full marks for "running properly" and "design". To earn full marks in "extra" the user must not be able to play cards that the game rules prohibit.
* *Can we assume that the user does not try to cheat by playing cards that are not in their hand*  
You may make this assumption and still earn full marks for "running properly" and "design". To earn full marks in the "extra" category the user must not be able to play cards that are not in their hand. 


**What to hand in**:

Templates for the five source files are located in the Assignment 4 workspace on Codio. In addition to the source files include a text file named readMe.txt with an explanation of how your program works. That is, write in plain English, instructions for using your software, explanations for how and why you chose to design your code the way you did. The readMe.txt file is also an opportunity for you to get partial credit when certain requirements of the assignment are not met.  

### Submitting your assignment
Once again we will be using Gradescope to submit your work. Please only submit your .java files (do not include .class files) and your readMe.txt file under Programming Project 4.
    


### A word about Grading: 
Your submission will be graded using the following guidelines: 

* 30% if it compiles  
* 30% if it runs properly (expected output for given input, etc.)  
* 15% for style (formatting of code, variable names, comments, etc. Use the style guide posted on Courseworks!)  
* 15% for design (efficiency, class  organization, method length, etc...)  
* 10% for "extra". We’ll discuss this in lecture but basically 10% of each programming project is reserved for students that go the extra mile and make their project fun, easy to use, readable, and just plain awesome. You can still earn 90% by satisfying the bare minimum requirements as spelled out above but those that go the extra mile will be recognized.


Please make sure your program at least compiles before you submit! There will be no partial credit for a program that "almost" compiles.


