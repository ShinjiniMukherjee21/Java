/** Player.java
*   Author: Shinjini Mukherjee
*   UNI: sm5160
*   
*   Player class as part of Crazy Eights
*   To be used with Game, Card, Deck classes
*
*/

import java.util.ArrayList;
import java.util.Scanner;

class Player{
    
    private ArrayList<Card> hand; //the player's hand
    private Scanner input;

    public Player(){
    
        hand = new ArrayList<Card>();
        input = new Scanner (System.in);

    }

    // Adds a card to the player's hand
    public void addCard(Card c){

        hand.add(c);

    }
   
    // Covers all the logic regarding a human player's turn
    // public so it may be called by the Game class
    public Card playsTurn(Deck deck){
        
        //return null if deck size is 0
        //ask user if they want to draw or play a card in their hand
        //depending on input, either add a card to hand (draw) or play the chosen card 
        //return the card that was played
        //this method will be called in play() in Game class

        while(true) {

            System.out.println("Type 'draw' to draw a card, or type the number next to the card in your hand that you wish to play");
            Scanner input = new Scanner(System.in);
            String playerTurn = input.nextLine();

            if(!playerTurn.equals("draw")) {
                int playerInt = Integer.parseInt(playerTurn);
                Card returnCard = hand.get(playerInt - 1); //playerInt-1 because indices of arraylist start at 0 not 1
                System.out.println("\n" + "** You played a " + returnCard.toString() + " **");
                hand.remove(playerInt - 1);
                return returnCard;

            }

            else if (deck.canDeal() == true) {
                Card draw = deck.deal();
                hand.add(draw);
                System.out.println("Your cards are now: ");
                System.out.println(handToString());
            } 
                
            else if (deck.canDeal() == false) {
                break;
            }
            
        }
        
    return null;

    }

    // Accessor for the players hand
    public ArrayList<Card> getHand(){
        
        return hand;

    }

    // Returns a printable string representing the player's hand
    public String handToString(){
        //use toString from Card class

        String output = "";
        int position = 0;

        for (int i = 0; i < hand.size(); i++) {
            position = i + 1;
            output += position + "      " + hand.get(i).toString() + "\n";
        }

        return output;
    }


} // end
