

class Test{
    public static void main(String[] args){

        Card random = new Card ('d', 1);

        System.out.println (random.getSuit());

        System.out.println (random.getRank());

        System.out.println (random.toString());

        Deck tester = new Deck();

        tester.canDeal();
        
        tester.deal();

        tester.shuffle();

        System.out.println(tester.toString());

    }

}    