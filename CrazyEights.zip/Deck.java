/** Deck.java
*   Author: Shinjini Mukherjee
*   UNI: sm5160
*
*   Models a typical deck of playing cards
*   To be used with Card class
*
*/

import java.util.Random;

class Deck{

    private Card[] deck; // contains the cards to play with
    private int top; // controls the "top" of the deck to deal from
    public static final char[] suits = {'c', 'd', 'h', 's'};

    // constructs a default Deck
    public Deck(){
        // nested for loop --> one varying rank, one varying suit
        //count keeps track of position in deck (0-51)

        int count = 0;
        top = 0;
        deck = new Card[52];

        for(int s = 0; s <= 3; s++) {
            for(int r = 1; r <= 13; r++) {

                deck[count] = new Card (suits[s], r);
                count ++;

            }
        }

    }

    // Deals the top card off the deck
    public Card deal(){
        // increment top and then return top card
        
        if (top <= 51 && top >= 0) {
            top++;
            return deck[top - 1];
        }
        
        else return null;
    }


    // returns true provided there is a card left in the deck to deal
    public boolean canDeal(){
        //check top card to make sure not 52

        if (top <= 51) {
            return true;
        }

        else {
            return false;
        }
        
    }

    // Shuffles the deck
    public void shuffle(){
        // pick a random index 0-51, exchange the temp card with random card

        Card temp;
        int randomOne;
        Random random = new Random();
        
        for (int i = 0; i < 52; i++) {
            randomOne = random.nextInt(52);
            temp = deck[i];
            deck[i] = deck[randomOne]; 
            deck[randomOne] = temp;
        }
        
    }

    // Returns a string representation of the whole deck
    public String toString(){
       // print every card in the deck

       String output = "";
       for(int i = 0; i < 52; i++) {
           output += (deck[i].toString()) + "\n";
       }

       return output; 

    }

    public int getLength() {
        return deck.length;
    }

} //end